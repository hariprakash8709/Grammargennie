import datetime

from config import MISTAKES_FILE


def save_mistake(original, corrected):
    """Log a mistake to mistakes.txt, but only if something actually changed."""
    if original.strip().lower() == corrected.strip().lower():
        return

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    with open(MISTAKES_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] You said: {original}\n")
        f.write(f"[{timestamp}] Correct:  {corrected}\n\n")


def get_recent_mistakes(limit=5):
    """Return the last `limit` logged mistakes."""
    try:
        with open(MISTAKES_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()
        if not content:
            return []
        entries = content.split("\n\n")
        return entries[-limit:]
    except FileNotFoundError:
        return []