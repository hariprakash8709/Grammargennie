# config.py - central settings for the project

SPEECH_RATE = 170
MISTAKES_FILE = "mistakes.txt"

# Get a free key at https://console.groq.com/keys (no billing needed)
GROQ_API_KEY = "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"