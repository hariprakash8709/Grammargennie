from groq import Groq
from config import GROQ_API_KEY

client = Groq(api_key=GROQ_API_KEY)


def correct_english(user_text):
    prompt = f"""You are a friendly English speaking coach having a live voice conversation.
The student just said: "{user_text}"

Respond in EXACTLY this format (keep the labels, two lines only):
REPLY: <a short, natural, conversational reply, 1 sentence>
CORRECTION: <the corrected, grammatically fluent version of what they said>

No extra text, no headers, nothing else."""

    try:
        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[{"role": "user", "content": prompt}]
        )
        text = response.choices[0].message.content.strip()

        reply_line = ""
        correction_line = user_text

        for line in text.split("\n"):
            line = line.strip()
            if line.upper().startswith("REPLY:"):
                reply_line = line.split(":", 1)[1].strip()
            elif line.upper().startswith("CORRECTION:"):
                correction_line = line.split(":", 1)[1].strip()

        if not reply_line:
            reply_line = "Got it!"

        return reply_line, correction_line

    except Exception as e:
        return f"AI unavailable: {e}", user_text