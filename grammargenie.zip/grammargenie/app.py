import os
import datetime

from dotenv import load_dotenv
from flask import Flask, request, jsonify, render_template_string
from groq import Groq

load_dotenv()

app = Flask(__name__)

GROQ_API_KEY = os.environ.get("GROQ_API_KEY")
client = Groq(api_key=GROQ_API_KEY) if GROQ_API_KEY else None

MISTAKES_FILE = os.path.join(os.path.dirname(__file__), "mistakes.txt")


def correct_english(user_text):
    if client is None:
        return "AI is not configured yet (missing GROQ_API_KEY).", user_text

    prompt = f"""You are a friendly English speaking coach having a live voice conversation.
The student just said: "{user_text}"

Respond in EXACTLY this format (keep the labels, two lines only):
REPLY: <a short, natural, conversational reply, 1 sentence>
CORRECTION: <the corrected, grammatically fluent version of what they said>

No extra text, no headers, nothing else."""

    try:
        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[{"role": "user", "content": prompt}],
        )
        text = response.choices[0].message.content.strip()

        reply_line = ""
        correction_line = user_text

        for line in text.split("\n"):
            line = line.strip()
            if line.upper().startswith("REPLY:"):
                reply_line = line.split(":", 1)[1].strip()
            elif line.upper().startswith("CORRECTION:"):
                correction_line = line.split(":", 1)[1].strip()

        if not reply_line:
            reply_line = "Got it!"

        return reply_line, correction_line

    except Exception as e:
        return f"AI unavailable right now ({e})", user_text


def save_mistake(original, corrected):
    if original.strip().lower() == corrected.strip().lower():
        return
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    try:
        with open(MISTAKES_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{timestamp}] You said: {original}\n")
            f.write(f"[{timestamp}] Correct:  {corrected}\n\n")
    except Exception as e:
        print(f"Could not save mistake: {e}")


@app.route("/")
def index():
    return render_template_string(PAGE_HTML)


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(force=True) or {}
    user_text = (data.get("text") or "").strip()

    if not user_text:
        return jsonify({"error": "empty"}), 400

    if user_text.lower() in ["exit", "quit", "stop", "bye"]:
        return jsonify({
            "reply": "Goodbye! Keep practicing English.",
            "corrected": user_text,
            "changed": False,
            "end": True,
        })

    reply, corrected = correct_english(user_text)
    changed = corrected.strip().lower() != user_text.strip().lower()
    save_mistake(user_text, corrected)

    return jsonify({
        "reply": reply,
        "corrected": corrected,
        "changed": changed,
        "end": False,
    })


PAGE_HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>English Tutor</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<style>
:root{
  --paper: #FBF7EC;
  --paper-line: #E4DCC4;
  --ink: #23262B;
  --ink-soft: #5B5F66;
  --indigo: #3A4CA6;
  --coral: #D9502C;
  --sage: #5E8F63;
  --board: #24382F;
  --panel-shadow: rgba(35,38,43,0.12);
}
*{ box-sizing: border-box; }
body{
  margin:0;
  background: var(--paper);
  background-image: linear-gradient(var(--paper-line) 1px, transparent 1px);
  background-size: 100% 2.1rem;
  color: var(--ink);
  font-family: 'Inter', sans-serif;
  -webkit-font-smoothing: antialiased;
}
.page{
  max-width: 100%;
  min-height: 100vh;
  margin: 0 auto;
  padding: 2rem 3rem 3rem;
}
.masthead{ margin-bottom: 2.2rem; }
.eyebrow{
  display:inline-block;
  font-family:'JetBrains Mono', monospace;
  font-size: 0.72rem;
  letter-spacing: 0.09em;
  text-transform: uppercase;
  color: var(--indigo);
  background: #EDEFFA;
  border: 1px solid #CBD1F0;
  padding: 0.2rem 0.55rem;
  border-radius: 4px;
}
.masthead h1{
  font-family:'Fraunces', serif;
  font-weight: 600;
  font-size: clamp(2.2rem, 5vw, 3.1rem);
  margin: 0.5rem 0 0.35rem;
  letter-spacing: -0.01em;
}
.tagline{ color: var(--ink-soft); font-size: 1.02rem; margin: 0; max-width: 46ch; }
.layout{
  display: grid;
  grid-template-columns: minmax(480px, 40vw) 1fr;
  gap: 2.5rem;
  align-items: stretch;
  min-height: 75vh;
}
@media (max-width: 820px){ .layout{ grid-template-columns: 1fr; } }
.stage{
  background: var(--board);
  border-radius: 20px;
  padding: 1.5rem;
  box-shadow: 0 10px 30px var(--panel-shadow);
  position: sticky;
  top: 1.5rem;
  display: flex;
  flex-direction: column;
  height: 100%;
}
#avatarCanvas{ display:block; width: 100%; height: auto; flex: 1; border-radius: 10px; background: #fff; }
.status-bar{
  margin-top: 0.85rem;
  background: #1B2A23;
  color: #EAF2ED;
  font-weight: 600;
  font-size: 0.95rem;
  padding: 0.7rem 0.9rem;
  border-radius: 8px;
  text-align: center;
  min-height: 1.3em;
}
.controls{ display:flex; align-items:center; gap: 0.6rem; margin-top: 0.9rem; }
.mic-btn{
  flex: 0 0 auto; width: 50px; height: 50px; border-radius: 50%;
  border: none; background: var(--coral); color: #fff;
  display:flex; align-items:center; justify-content:center; cursor:pointer;
  transition: transform 0.15s ease, background 0.15s ease;
}
.mic-btn:hover{ transform: scale(1.05); }
.mic-btn.listening{ background: var(--sage); animation: pulse 1.1s infinite; }
@keyframes pulse{
  0%{ box-shadow: 0 0 0 0 rgba(94,143,99,0.55); }
  70%{ box-shadow: 0 0 0 12px rgba(94,143,99,0); }
  100%{ box-shadow: 0 0 0 0 rgba(94,143,99,0); }
}
.text-form{ flex: 1 1 auto; }
#textInput{
  width: 100%; padding: 0.75rem 0.9rem; border-radius: 10px;
  border: 1px solid #37503F; background: #16221C; color: #EAF2ED; font-size: 0.95rem;
}
#textInput::placeholder{ color: #7FA08B; }
#textInput:focus{ outline: 2px solid var(--indigo); outline-offset: 1px; }
.hint{ color: #9FC0AC; font-size: 0.78rem; margin: 0.7rem 0.2rem 0.1rem; }
.notebook{
  background: #fff; border: 1px solid var(--paper-line); border-radius: 20px;
  padding: 1.5rem 1.8rem 1.8rem; height: 100%;
  display: flex; flex-direction: column; box-shadow: 0 10px 30px var(--panel-shadow);
}
.notebook-head{ display:flex; align-items:center; justify-content: space-between; margin-bottom: 0.9rem; }
.clear-btn{ border:none; background:none; color: var(--ink-soft); font-family:'JetBrains Mono', monospace; font-size: 0.75rem; cursor:pointer; text-decoration: underline; }
.clear-btn:hover{ color: var(--coral); }
.feed{ display:flex; flex-direction: column; gap: 0.9rem; flex: 1; overflow-y: auto; }
.empty-note{ color: var(--ink-soft); font-style: italic; font-size: 0.95rem; }
.msg{ max-width: 92%; padding: 0.65rem 0.9rem; border-radius: 12px; font-size: 0.98rem; line-height: 1.45; }
.msg.user{ align-self: flex-end; background: var(--indigo); color: #fff; border-bottom-right-radius: 3px; }
.msg.bot{ align-self: flex-start; background: #F1F0E8; color: var(--ink); border-bottom-left-radius: 3px; }
.correction{ align-self: flex-start; max-width: 92%; border-left: 3px solid var(--coral); padding: 0.45rem 0.7rem; background: #FDF1EC; border-radius: 0 8px 8px 0; }
.correction .label{ display:block; font-family:'JetBrains Mono', monospace; font-size: 0.68rem; letter-spacing: 0.06em; text-transform: uppercase; color: var(--coral); margin-bottom: 0.15rem; }
.correction .text{ font-family:'JetBrains Mono', monospace; font-size: 0.9rem; color: #7A2E17; }
.foot-note{ text-align:center; color: var(--ink-soft); font-size: 0.82rem; margin-top: 2.2rem; }
</style>
</head>
<body>

<div class="page">
  <header class="masthead">
    <span class="eyebrow">Room 4B · Speaking Practice</span>
    <h1>English Tutor</h1>
    <p class="tagline">Speak a sentence. Get a natural reply, and a red-pen correction in the margin.</p>
  </header>

  <main class="layout">
    <section class="stage">
      <canvas id="avatarCanvas" width="560" height="560"></canvas>
      <div id="statusBar" class="status-bar">Starting up…</div>
      <div class="controls">
        <button id="micBtn" class="mic-btn" title="Tap to speak">
          <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
            <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
            <line x1="12" y1="19" x2="12" y2="23"/>
            <line x1="8" y1="23" x2="16" y2="23"/>
          </svg>
        </button>
        <form id="textForm" class="text-form">
          <input id="textInput" type="text" placeholder="…or type a sentence and press Enter" autocomplete="off">
        </form>
      </div>
      <p class="hint">Voice input works best in Chrome or Edge. No mic access? Just type instead.</p>
    </section>

    <section class="notebook">
      <div class="notebook-head">
        <span class="eyebrow">Transcript</span>
        <button id="clearBtn" class="clear-btn">clear</button>
      </div>
      <div id="feed" class="feed">
        <div class="empty-note">Nothing here yet — say hello to begin.</div>
      </div>
    </section>
  </main>

  <footer class="foot-note">Built for practice, not perfection — every correction here is a step forward.</footer>
</div>

<script>
class Avatar {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas.getContext("2d");
    this.w = 380; this.h = 380;
    const scale = this.canvas.width / this.w;
    this.ctx.scale(scale, scale);
    this.talking = false; this.mouthOpen = false; this.blink = false; this.tick = 0;
    this.skin = "#e8b48a"; this.hair = "#2b2320";
    this.blazer = "#2c3e60"; this.blazerDark = "#213050";
    this.shirt = "#ffffff"; this.tie = "#a83232";
    this._loop();
  }
  setTalking(talking) { this.talking = talking; }
  _drawClassroom() {
    const c = this.ctx;
    c.fillStyle = "#f1ecd9"; c.fillRect(0, 0, this.w, 300);
    c.fillStyle = "#c9a876"; c.fillRect(0, 300, this.w, 80);
    c.strokeStyle = "#b8944f"; c.lineWidth = 1;
    for (let x = 0; x < this.w; x += 40) { c.beginPath(); c.moveTo(x, 300); c.lineTo(x, 380); c.stroke(); }
    c.fillStyle = "#28453a"; c.strokeStyle = "#6b4a2b"; c.lineWidth = 5;
    c.fillRect(20, 25, 140, 85); c.strokeRect(20, 25, 140, 85);
    c.fillStyle = "#f1ecd9"; c.font = "bold 13px monospace"; c.textAlign = "center";
    c.fillText("A B C", 90, 54);
    c.font = "italic 11px monospace"; c.fillText("Hello!", 90, 79);
    c.strokeStyle = "#f1ecd9"; c.lineWidth = 1;
    c.beginPath(); c.moveTo(40, 92); c.lineTo(140, 92); c.stroke();
    c.fillStyle = "#6b4a2b"; c.fillRect(20, 110, 140, 6);
    c.fillStyle = "#bfe3f2"; c.strokeStyle = "#8a6d4a"; c.lineWidth = 5;
    c.fillRect(250, 25, 110, 105); c.strokeRect(250, 25, 110, 105);
    c.lineWidth = 3; c.beginPath();
    c.moveTo(305, 25); c.lineTo(305, 130); c.moveTo(250, 77); c.lineTo(360, 77); c.stroke();
    c.fillStyle = "#7a4e2d"; c.strokeStyle = "#4a2f1a"; c.lineWidth = 2;
    c.fillRect(330, 150, 45, 110); c.strokeRect(330, 150, 45, 110);
    const bookColors = ["#e63946", "#457b9d", "#2a9d8f", "#f4a261"];
    bookColors.forEach((col, i) => { c.fillStyle = col; c.fillRect(334 + i * 10, 158, 8, 96); });
  }
  _draw() {
    const c = this.ctx;
    c.clearRect(0, 0, this.w, this.h);
    this._drawClassroom();
    const cx = 190;
    c.fillStyle = this.blazer;
    c.beginPath();
    c.moveTo(cx - 90, 380); c.lineTo(cx - 55, 250); c.lineTo(cx - 20, 235);
    c.lineTo(cx + 20, 235); c.lineTo(cx + 55, 250); c.lineTo(cx + 90, 380);
    c.closePath(); c.fill();
    c.fillStyle = this.blazerDark;
    c.beginPath();
    c.moveTo(cx + 5, 240); c.lineTo(cx + 45, 380); c.lineTo(cx + 15, 380); c.lineTo(cx - 5, 260);
    c.closePath(); c.fill();
    c.fillStyle = this.shirt;
    c.beginPath(); c.moveTo(cx - 22, 240); c.lineTo(cx, 275); c.lineTo(cx - 6, 240); c.closePath(); c.fill();
    c.beginPath(); c.moveTo(cx + 22, 240); c.lineTo(cx, 275); c.lineTo(cx + 6, 240); c.closePath(); c.fill();
    c.fillStyle = this.tie;
    c.beginPath();
    c.moveTo(cx - 6, 250); c.lineTo(cx + 6, 250); c.lineTo(cx + 10, 300); c.lineTo(cx, 315); c.lineTo(cx - 10, 300);
    c.closePath(); c.fill();
    c.fillStyle = this.skin; c.fillRect(cx - 15, 210, 30, 35);
    c.beginPath(); c.ellipse(cx, 132, 65, 78, 0, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.ellipse(cx - 62, 125, 8, 15, 0, 0, Math.PI * 2); c.fill();
    c.beginPath(); c.ellipse(cx + 62, 125, 8, 15, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = this.hair;
    c.beginPath(); c.arc(cx, 100, 66, Math.PI, 0); c.fill();
    c.fillRect(cx - 66, 95, 14, 35); c.fillRect(cx + 52, 95, 14, 35);
    c.strokeStyle = "#1f2937"; c.lineWidth = 3;
    c.strokeRect(cx - 38, 110, 26, 25); c.strokeRect(cx + 12, 110, 26, 25);
    c.beginPath();
    c.moveTo(cx - 12, 122); c.lineTo(cx + 12, 122);
    c.moveTo(cx - 44, 118); c.lineTo(cx - 38, 115);
    c.moveTo(cx + 38, 115); c.lineTo(cx + 44, 118);
    c.stroke();
    c.fillStyle = this.hair;
    c.fillRect(cx - 34, 100, 18, 5); c.fillRect(cx + 16, 100, 18, 5);
    c.fillStyle = "#1f2937";
    if (this.blink) {
      c.lineWidth = 2; c.beginPath();
      c.moveTo(cx - 30, 122); c.lineTo(cx - 18, 122);
      c.moveTo(cx + 18, 122); c.lineTo(cx + 30, 122); c.stroke();
    } else {
      c.beginPath(); c.ellipse(cx - 24, 122, 4, 6, 0, 0, Math.PI * 2); c.fill();
      c.beginPath(); c.ellipse(cx + 24, 122, 4, 6, 0, 0, Math.PI * 2); c.fill();
    }
    c.strokeStyle = "#c9986a"; c.lineWidth = 2;
    c.beginPath(); c.moveTo(cx, 135); c.lineTo(cx, 150); c.stroke();
    c.fillStyle = "#7a2f28";
    if (this.talking && this.mouthOpen) {
      c.beginPath(); c.ellipse(cx, 169, 14, 9, 0, 0, Math.PI * 2); c.fill();
    } else {
      c.strokeStyle = "#7a2f28"; c.lineWidth = 4; c.lineCap = "round";
      c.beginPath(); c.moveTo(cx - 14, 168); c.lineTo(cx + 14, 168); c.stroke();
    }
  }
  _loop() {
    this.tick++;
    this.mouthOpen = this.talking ? !this.mouthOpen : false;
    this.blink = this.tick % 25 === 0;
    this._draw();
    setTimeout(() => this._loop(), 200);
  }
}

const avatar = new Avatar("avatarCanvas");
const statusBar = document.getElementById("statusBar");
const micBtn = document.getElementById("micBtn");
const textForm = document.getElementById("textForm");
const textInput = document.getElementById("textInput");
const feed = document.getElementById("feed");
const clearBtn = document.getElementById("clearBtn");
let busy = false;
let continuousMode = false;

function setStatus(t){ statusBar.textContent = t; }
function clearEmptyNote(){ const n = feed.querySelector(".empty-note"); if(n) n.remove(); }
function addUserMessage(t){ clearEmptyNote(); const d=document.createElement("div"); d.className="msg user"; d.textContent=t; feed.appendChild(d); feed.scrollTop=feed.scrollHeight; }
function addBotMessage(t){ clearEmptyNote(); const d=document.createElement("div"); d.className="msg bot"; d.textContent=t; feed.appendChild(d); feed.scrollTop=feed.scrollHeight; }
function addCorrection(t){
  clearEmptyNote();
  const d=document.createElement("div"); d.className="correction";
  const label=document.createElement("span"); label.className="label"; label.textContent="Correct way to say it";
  const body=document.createElement("span"); body.className="text"; body.textContent=t;
  d.appendChild(label); d.appendChild(body); feed.appendChild(d); feed.scrollTop=feed.scrollHeight;
}

function speak(text, onDone) {
  if (!("speechSynthesis" in window)) { onDone && onDone(); return; }
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 1.0; u.pitch = 1.0;
  u.onstart = () => avatar.setTalking(true);
  u.onend = () => { avatar.setTalking(false); onDone && onDone(); };
  u.onerror = () => { avatar.setTalking(false); onDone && onDone(); };
  window.speechSynthesis.speak(u);
}

function speakSequence(lines, finalStatus, conversationEnded) {
  let i = 0;
  function next() {
    if (i >= lines.length) {
      setStatus(finalStatus);
      busy = false;
      micBtn.disabled = false;
      if (conversationEnded) {
        continuousMode = false;
        micBtn.classList.remove("listening");
      } else if (continuousMode && recognition) {
        setTimeout(() => { try { recognition.start(); } catch(e) {} }, 400);
      }
      return;
    }
    const line = lines[i++];
    setStatus(line.length > 60 ? line.slice(0,57)+"…" : line);
    speak(line, next);
  }
  next();
}

async function sendToTutor(userText) {
  if (!userText || busy) return;
  busy = true; micBtn.disabled = true;
  addUserMessage(userText);
  setStatus("Thinking…");
  try {
    const res = await fetch("/api/chat", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({text: userText})
    });
    const data = await res.json();
    if (data.error) { setStatus("Hmm, something went wrong. Try again."); busy=false; micBtn.disabled=false; return; }
    addBotMessage(data.reply);
    const toSpeak = [data.reply];
    if (data.changed) { addCorrection(data.corrected); toSpeak.push(`Correct way to say that: ${data.corrected}`); }
    speakSequence(
      toSpeak,
      data.end ? "Conversation ended. Tap mic to start again." : "Listening again…",
      data.end
    );
  } catch(e) {
    setStatus("Network error — check your connection."); busy=false; micBtn.disabled=false;
  }
}

const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null, listening = false;
if (SR) {
  recognition = new SR();
  recognition.lang = "en-US"; recognition.interimResults = false; recognition.maxAlternatives = 1;
  recognition.onstart = () => { listening=true; micBtn.classList.add("listening"); setStatus("Listening…"); };
  recognition.onresult = (e) => sendToTutor(e.results[0][0].transcript);
  recognition.onerror = (e) => {
    if (e.error === "no-speech" && continuousMode) {
      setTimeout(() => { try { recognition.start(); } catch(err) {} }, 400);
    } else {
      setStatus("Didn't catch that — tap mic to try again.");
    }
  };
  recognition.onend = () => { listening=false; micBtn.classList.remove("listening"); };
} else {
  micBtn.title = "Voice input isn't supported in this browser — please type instead.";
}

micBtn.addEventListener("click", () => {
  if (!recognition) { setStatus("Voice input isn't supported here — please type your sentence."); textInput.focus(); return; }
  if (continuousMode) {
    continuousMode = false;
    recognition.stop();
    setStatus("Stopped. Tap mic to start again.");
    return;
  }
  if (busy) return;
  continuousMode = true;
  try { recognition.start(); } catch(e) {}
});

textForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const val = textInput.value.trim();
  if (!val) return;
  textInput.value = "";
  sendToTutor(val);
});

clearBtn.addEventListener("click", () => {
  feed.innerHTML = '<div class="empty-note">Nothing here yet — say hello to begin.</div>';
});

const GREETINGS = [
  "Hey there! I'm your English buddy. Let's practice speaking!",
  "Hi! Ready to learn some English today?",
  "Welcome back! Let's work on your English skills.",
];

window.addEventListener("load", () => {
  const greeting = GREETINGS[Math.floor(Math.random()*GREETINGS.length)];
  addBotMessage(greeting);
  busy = true; micBtn.disabled = true;
  speak(greeting, () => {
    const line2 = "Tap the mic and start speaking, or type below. Say exit to stop.";
    addBotMessage(line2);
    speak(line2, () => { setStatus("Tap mic to speak"); busy=false; micBtn.disabled=false; });
  });
});
</script>
</body>
</html>
"""


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug_mode = os.environ.get("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=port, debug=debug_mode)