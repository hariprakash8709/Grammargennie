import speech_recognition as sr
import pyttsx3

from config import SPEECH_RATE

recognizer = sr.Recognizer()
recognizer.energy_threshold = 300
recognizer.dynamic_energy_threshold = True
recognizer.pause_threshold = 0.8

mic = sr.Microphone()


def speak(text, avatar=None):
    print(f"Assistant: {text}")
    if avatar:
        avatar.set_talking(True, text)

    engine = pyttsx3.init()
    engine.setProperty('rate', SPEECH_RATE)
    engine.setProperty('volume', 1.0)
    engine.say(text)
    engine.runAndWait()
    engine.stop()
    del engine

    if avatar:
        avatar.set_talking(False)


def calibrate():
    with mic as source:
        print("Calibrating mic for background noise... (just a moment)")
        recognizer.adjust_for_ambient_noise(source, duration=1)


def listen():
    with mic as source:
        print("Listening...")
        try:
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=15)
        except sr.WaitTimeoutError:
            return ""

    try:
        text = recognizer.recognize_google(audio)
        print(f"You said: {text}")
        return text
    except sr.UnknownValueError:
        return ""
    except sr.RequestError:
        speak("Speech service is unavailable right now.")
        return ""