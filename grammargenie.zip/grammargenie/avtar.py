import random
import tkinter as tk

GREETINGS = [
    "Hey there! I'm your English buddy. Let's practice speaking!",
    "Hi! Ready to learn some English today?",
    "Welcome back! Let's work on your English skills."
]

ENCOURAGEMENTS = [
    "Nice try! Keep going.",
    "You're improving!",
    "Almost there!",
    "Good effort!"
]

PRAISE = [
    "Awesome!",
    "Perfect!",
    "You nailed it!"
]


def greet():
    return random.choice(GREETINGS)


def farewell():
    return "Goodbye! Keep practicing English."


def react(is_correct):
    if is_correct:
        return random.choice(PRAISE)
    return random.choice(ENCOURAGEMENTS)


class AvatarWindow:
    """A clean, flat-design professional tutor in a flat classroom scene."""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("English Tutor")
        self.root.geometry("420x540")
        self.root.configure(bg="#eef2f7")
        self.root.resizable(False, False)

        title = tk.Label(
            self.root, text="English Tutor", font=("Segoe UI", 16, "bold"),
            bg="#eef2f7", fg="#1f2937"
        )
        title.pack(pady=(14, 0))

        self.canvas = tk.Canvas(self.root, width=380, height=380,
                                 bg="#ffffff", highlightthickness=1,
                                 highlightbackground="#d1d9e6")
        self.canvas.pack(pady=14)

        self.status_label = tk.Label(
            self.root, text="Starting up...", font=("Segoe UI", 12, "bold"),
            bg="#1f2937", fg="#ffffff", wraplength=360, justify="center",
            padx=14, pady=10
        )
        self.status_label.pack(pady=(0, 16), fill="x", padx=20)

        self.talking = False
        self.mouth_open = False
        self.blink = False
        self.tick = 0

        self.skin = "#e8b48a"
        self.hair = "#2b2320"
        self.blazer = "#2c3e60"
        self.blazer_dark = "#213050"
        self.shirt = "#ffffff"
        self.tie = "#a83232"

        self._draw_scene()
        self._animate()

    def _draw_classroom(self):
        c = self.canvas

        c.create_rectangle(0, 0, 380, 300, fill="#f1ecd9", outline="")
        c.create_rectangle(0, 300, 380, 380, fill="#c9a876", outline="")
        for x in range(0, 380, 40):
            c.create_line(x, 300, x, 380, fill="#b8944f", width=1)

        c.create_rectangle(20, 25, 160, 110, fill="#28453a", outline="#6b4a2b", width=5)
        c.create_text(90, 50, text="A B C", fill="#f1ecd9", font=("Courier", 13, "bold"))
        c.create_text(90, 75, text="Hello!", fill="#f1ecd9", font=("Courier", 11, "italic"))
        c.create_line(40, 92, 140, 92, fill="#f1ecd9", width=1)

        c.create_rectangle(20, 110, 160, 116, fill="#6b4a2b", outline="")

        c.create_rectangle(250, 25, 360, 130, fill="#bfe3f2", outline="#8a6d4a", width=5)
        c.create_line(305, 25, 305, 130, fill="#8a6d4a", width=3)
        c.create_line(250, 77, 360, 77, fill="#8a6d4a", width=3)

        c.create_rectangle(330, 150, 375, 260, fill="#7a4e2d", outline="#4a2f1a", width=2)
        book_colors = ["#e63946", "#457b9d", "#2a9d8f", "#f4a261"]
        for i, col in enumerate(book_colors):
            c.create_rectangle(334 + i * 10, 158, 342 + i * 10, 254, fill=col, outline="")

    def _draw_scene(self):
        c = self.canvas
        c.delete("all")

        self._draw_classroom()

        cx = 190

        c.create_polygon(
            cx - 90, 380, cx - 55, 250, cx - 20, 235,
            cx + 20, 235, cx + 55, 250, cx + 90, 380,
            fill=self.blazer, outline=""
        )
        c.create_polygon(
            cx + 5, 240, cx + 45, 380, cx + 15, 380, cx - 5, 260,
            fill=self.blazer_dark, outline=""
        )

        c.create_polygon(cx - 22, 240, cx, 275, cx - 6, 240, fill=self.shirt, outline="")
        c.create_polygon(cx + 22, 240, cx, 275, cx + 6, 240, fill=self.shirt, outline="")

        c.create_polygon(cx - 6, 250, cx + 6, 250, cx + 10, 300, cx, 315, cx - 10, 300,
                          fill=self.tie, outline="")

        c.create_rectangle(cx - 15, 210, cx + 15, 245, fill=self.skin, outline="")

        c.create_oval(cx - 65, 55, cx + 65, 210, fill=self.skin, outline="")

        c.create_oval(cx - 70, 110, cx - 55, 140, fill=self.skin, outline="")
        c.create_oval(cx + 55, 110, cx + 70, 140, fill=self.skin, outline="")

        c.create_arc(cx - 66, 40, cx + 66, 160, start=0, extent=180,
                      fill=self.hair, outline="")
        c.create_rectangle(cx - 66, 95, cx - 52, 130, fill=self.hair, outline="")
        c.create_rectangle(cx + 52, 95, cx + 66, 130, fill=self.hair, outline="")

        c.create_rectangle(cx - 38, 110, cx - 12, 135, outline="#1f2937", width=3)
        c.create_rectangle(cx + 12, 110, cx + 38, 135, outline="#1f2937", width=3)
        c.create_line(cx - 12, 122, cx + 12, 122, fill="#1f2937", width=3)
        c.create_line(cx - 44, 118, cx - 38, 115, fill="#1f2937", width=3)
        c.create_line(cx + 38, 115, cx + 44, 118, fill="#1f2937", width=3)

        c.create_rectangle(cx - 34, 100, cx - 16, 105, fill=self.hair, outline="")
        c.create_rectangle(cx + 16, 100, cx + 34, 105, fill=self.hair, outline="")

        if self.blink:
            c.create_line(cx - 30, 122, cx - 18, 122, width=2, fill="#1f2937")
            c.create_line(cx + 18, 122, cx + 30, 122, width=2, fill="#1f2937")
        else:
            c.create_oval(cx - 28, 116, cx - 20, 128, fill="#1f2937", outline="")
            c.create_oval(cx + 20, 116, cx + 28, 128, fill="#1f2937", outline="")

        c.create_line(cx, 135, cx, 150, fill="#c9986a", width=2)

        if self.talking and self.mouth_open:
            c.create_oval(cx - 14, 160, cx + 14, 178, fill="#7a2f28", outline="")
        else:
            c.create_line(cx - 14, 168, cx + 14, 168, width=4, fill="#7a2f28", capstyle="round")

    def _animate(self):
        self.tick += 1

        if self.talking:
            self.mouth_open = not self.mouth_open
        else:
            self.mouth_open = False

        self.blink = (self.tick % 25 == 0)

        self._draw_scene()
        self.root.after(200, self._animate)

    def set_talking(self, talking, status_text=None):
        self.talking = talking
        if status_text:
            self.status_label.config(text=status_text)

    def set_status(self, text):
        self.status_label.config(text=text)

    def start(self):
        self.root.mainloop()