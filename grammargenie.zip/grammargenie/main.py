import threading

from voice import listen, speak, calibrate
from grammar import correct_english
from memory import save_mistake
from avtar import greet, AvatarWindow

avatar = None


def assistant_loop():
    speak(greet(), avatar)
    calibrate()
    speak("Let's talk! Just start speaking anytime. Say 'exit' to stop.", avatar)

    while True:
        try:
            avatar.set_status("Listening...")
            user_text = listen()

            if not user_text:
                continue

            if user_text.lower() in ["exit", "quit", "stop", "bye"]:
                speak("Goodbye! Keep practicing English.", avatar)
                break

            avatar.set_status("Thinking...")
            conversational_reply, corrected = correct_english(user_text)

            try:
                save_mistake(user_text, corrected)
            except Exception as e:
                print(f"Could not save mistake: {e}")

            speak(conversational_reply, avatar)

            if corrected.strip().lower() != user_text.strip().lower():
                speak(f"Correct way to say that: {corrected}", avatar)

        except Exception as e:
            print(f"Something went wrong: {e}")
            speak("Sorry, something went wrong. Let's try again.", avatar)
            continue

    avatar.root.quit()


def main():
    global avatar
    avatar = AvatarWindow()

    t = threading.Thread(target=assistant_loop, daemon=True)
    t.start()

    avatar.start()


if __name__ == "__main__":
    main()